#ifndef CALCULATOR_H
#define CALCULATOR_H

#include <QMainWindow>
#include <QDebug>


QT_BEGIN_NAMESPACE
namespace Ui { class Calculator; }
QT_END_NAMESPACE

class Calculator : public QMainWindow
{
    Q_OBJECT

public:
    Calculator(QWidget *parent = nullptr);
    ~Calculator();

    QString toRPN(QString str);
    double operation(QString rpn);

private:
    Ui::Calculator *ui;
    char c;
    double a;
    double b;
    double result;
    int flag = 0;
    QString c_history;

private slots:
    void bt_cal_click();

    void bt_result_click();

    void bt_clear_click();

    void bt_backspace_click();

    void show_history();
};
#endif // CALCULATOR_H
