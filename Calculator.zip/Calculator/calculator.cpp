#include "calculator.h"
#include "ui_calculator.h"
#include <QStack>
#include <cmath>

Calculator::Calculator(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Calculator)
{
    ui->setupUi(this);
    ui->textEdit->setVisible(false);

    //信号与槽的绑定
    connect(ui->pushButton,SIGNAL(clicked(bool)),this,SLOT(bt_cal_click()));
    connect(ui->pushButton_2,SIGNAL(clicked(bool)),this,SLOT(bt_cal_click()));
    connect(ui->pushButton_3,SIGNAL(clicked(bool)),this,SLOT(bt_cal_click()));
    connect(ui->pushButton_4,SIGNAL(clicked(bool)),this,SLOT(bt_cal_click()));
    connect(ui->pushButton_5,SIGNAL(clicked(bool)),this,SLOT(bt_cal_click()));
    connect(ui->pushButton_6,SIGNAL(clicked(bool)),this,SLOT(bt_cal_click()));
    connect(ui->pushButton_7,SIGNAL(clicked(bool)),this,SLOT(bt_cal_click()));
    connect(ui->pushButton_8,SIGNAL(clicked(bool)),this,SLOT(bt_cal_click()));
    connect(ui->pushButton_9,SIGNAL(clicked(bool)),this,SLOT(bt_cal_click()));
    connect(ui->pushButton_10,SIGNAL(clicked(bool)),this,SLOT(bt_cal_click()));
    connect(ui->pushButton_11,SIGNAL(clicked(bool)),this,SLOT(bt_cal_click()));
    connect(ui->pushButton_13,SIGNAL(clicked(bool)),this,SLOT(bt_cal_click()));
    connect(ui->pushButton_14,SIGNAL(clicked(bool)),this,SLOT(bt_cal_click()));
    connect(ui->pushButton_15,SIGNAL(clicked(bool)),this,SLOT(bt_cal_click()));
    connect(ui->pushButton_16,SIGNAL(clicked(bool)),this,SLOT(bt_cal_click()));
    connect(ui->pushButton_20,SIGNAL(clicked(bool)),this,SLOT(bt_cal_click()));
    connect(ui->pushButton_21,SIGNAL(clicked(bool)),this,SLOT(bt_cal_click()));
    connect(ui->pushButton_22,SIGNAL(clicked(bool)),this,SLOT(bt_cal_click()));

    //功能按键信号与槽的绑定
    connect(ui->pushButton_17,SIGNAL(clicked(bool)),this,SLOT(bt_result_click()));// =
    connect(ui->pushButton_12,SIGNAL(clicked(bool)),this,SLOT(bt_clear_click()));// C
    connect(ui->pushButton_19,SIGNAL(clicked(bool)),this,SLOT(bt_backspace_click()));// B

    connect(ui->pushButton_18,SIGNAL(clicked(bool)),this,SLOT(show_history()));
}

Calculator::~Calculator()
{
    delete ui;
}


//0~9 . + - * / 的点击函数
void Calculator::bt_cal_click()
{
    //表示=已经被按下，下次重新计算时
    if(flag == 1)
    {
        flag = 0;
        ui->lineEdit->clear();
        ui->textEdit->setVisible(false);
    }
    //获取到是那个对象被点击
    QPushButton *q = dynamic_cast<QPushButton *>(sender());
    QString str = q->text();
   // qDebug() << str;

    //将点击后的值插入到行edit
    ui->lineEdit->insert(str);
}

//获取计算结果
void Calculator::bt_result_click()
{

    /* const char *buf = str.toStdString().c_str();
   sscanf(buf,"%lf%c%lf",&a,&c,&b);
   switch (c) {
   case '+':
       result = a + b;
       break;
   case '-':
       result = a - b;
       break;
   case '*':
       result = a * b;
       break;
   case '/':
       if(b == 0)
       {
           ui->lineEdit->insert("error: divide is zero");
           return;
       }
       result = a / b;
       break;
   default:
       ui->lineEdit->insert("no number");
       return;
   }*/
    flag = 1;//=被触发

    QString str = ui->lineEdit->text();
    /*调用中缀表达式->后缀表达式    对后缀表达式计算*/
    QString rpn = toRPN(str);
    result = operation(rpn);

    //将结果显示到lineedit
    QString s = QString::number(result);
    ui->lineEdit->insert("="+s);

    //保存到字符串中
    QString sh = ui->lineEdit->text();
    c_history += sh+"\n";
    return;
}

//清除行edit
void Calculator::bt_clear_click()
{
    ui->lineEdit->clear();
    return;
}

//退格
void Calculator::bt_backspace_click()
{
    if(flag == 1)
    {
        QString s = QString::number(result);
        ui->lineEdit->setText(s);
        return;
    }
    ui->lineEdit->backspace();
    return;
}

//显示历史记录
void Calculator::show_history()
{
   // qDebug() << "history";
    ui->textEdit->setVisible(true);
    ui->textEdit->show();
    ui->textEdit->setText(c_history);
    return;
}

//转换为后缀表达式
QString Calculator::toRPN(QString str)
{
    QString rpn;
    QStack<QChar> opStack;//存操作符

    for(auto i : str){
        //数字或小数点直接存入字符串
        if((i <= '9' && i >= '0') || i == '.'){
            rpn += i;
        }
        //左括号直接入栈
        if(i == '('){
            opStack.push(i);
        }
        //遇到右括号，出栈栈顶元素直到栈顶元素为左括号
        if(i == ')'){
            while(opStack.top() != '('){
                rpn += ' ';
                rpn += opStack.pop();
            }
            opStack.pop();//将左括号出栈
        }
        //运算符优先级不低于栈顶元素则入栈，否则出栈栈顶元素后入栈
        if(i == '+'||i == '-'){
            rpn += ' ';
            while(!opStack.empty() && opStack.top() != '(' && opStack.top() != '+' && opStack.top() != '-'){
                rpn += opStack.pop();
                rpn += ' ';
            }
            opStack.push(i);
        }
        if(i == '*'||i == '/'||i == '%'){
            rpn += ' ';
            opStack.push(i);
        }
    }
    //出栈所有元素
    while(!opStack.empty()){
        rpn += ' ';
        rpn += opStack.pop();
    }
    //qDebug() << str << rpn;
    return rpn;
}

double Calculator::operation(QString rpn)
{
    QStack<double> result;
    QString num;
    //遍历后缀表达式
    for(auto i : rpn){
        if((i >= '0' && i <= '9') || i == '.' || i == ' '){
            if((i >= '0' && i <= '9') || i == '.' ){
                num += i;
            }
            if(i == ' '){
                if(!num.isEmpty() && num.at(0) >= '0' && num.at(0) <= '9'){
                    result.push(num.toDouble());
                    num.clear();
                }
            }
        }
        //加法
        if(i == '+'){
            double temp1 = result.pop();
            double temp2 = result.pop();
            result.push(temp2+temp1);
        }
        //减法
        if(i == '-'){
            double temp1 = result.pop();
            double temp2 = result.pop();
            result.push(temp2-temp1);
        }
        //乘法
        if(i == '*'){
            double temp1 = result.pop();
            double temp2 = result.pop();
            result.push(temp2*temp1);
        }
        //除法
        if(i == '/'){
            double temp1 = result.pop();
            double temp2 = result.pop();
            result.push(temp2/temp1);
        }
        //模运算
        if(i == '%'){
            double temp1 = result.pop();
            double temp2 = result.pop();
            result.push(fmod(temp2,temp1));
        }
    }
    return result.top();
}
